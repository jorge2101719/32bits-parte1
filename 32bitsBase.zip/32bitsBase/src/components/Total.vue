<template>
    <div>
        <h3>
            Totales
        </h3>
    </div>
</template>