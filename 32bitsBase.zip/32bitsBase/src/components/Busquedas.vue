<template>
    <div>
        <h3>Página de búsquedas</h3>
        <input type="text" placeholder="ingrese el producto a buscar">
    </div>
</template>