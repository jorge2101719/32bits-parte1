<template>
    <div>
        <h1> {{titulo}} </h1>

        <h2> {{subtitulo}} </h2>

        <ul>
            <li v-for="(producto, clave) in productosConStock" :key="clave">
                <label> {{producto.codigo}} | {{producto.nombre}} | {{producto.stock}} | {{producto.precio}} | </label>
                <button type="button" class="btn btn-success btn-sm">Vender</button>
            </li>
        </ul>
    </div>
</template>

<script>
import {mapState} from 'vuex'
export default {
    computed: {
        titulo() {
            return '32bits'
        },
        subtitulo() {
            return 'Juegos de PC y consolas'
        },
        productosConStock() {
            return this.$store.getters.productosConStock
        }
    },
    ...mapState({
        totalVentas: (state) => {
            return `Total : ${state.totalVentas}`
        },
        destacado: () => {}
    })
}
</script>

<style scoped>
h1, h2 {
    text-align: center;
}
</style>
