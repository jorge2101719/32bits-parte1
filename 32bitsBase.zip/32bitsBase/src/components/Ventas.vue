<template>
    <div>
        <h3>
            Ventas
        </h3>
    </div>
</template>