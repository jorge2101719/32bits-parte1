import Vue from 'vue'
import Router from 'vue-router'
const Inicio = () => import('./components/Inicio')
const Busqueda = () => import('./components/Busquedas')
const Ventas = () => import('./components/Ventas')
const Total = () => import('./components/Total')

Vue.use(Router)

export default new Router({
    mode: 'history', 
    routes: [
        {
            path: '/',
            name: 'inicio',
            component: Inicio
        },
        {
            path: '/Busquedas',
            name: 'busquedas',
            component: Busqueda
        },
        {
            path: 'Ventas',
            name: 'ventas',
            component: Ventas
        },
        {
            path: 'Total',
            name: 'total',
            component: Total
        }
    ]
})