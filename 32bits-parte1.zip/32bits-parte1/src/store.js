import Vue from 'vue';
import Vuex from 'vuex';

Vue.use(Vuex);

const store = new Vuex.Store({
  state: {
    busqueda: "",
    productos: [
      {
        codigo: '0001',
        nombre: 'Sekiro',
        stock: 100,
        precio: 30000,
        color: 'red',
        destacado: true
      },
      {
        codigo: '0002',
        nombre: 'Fifa',
        stock: 100,
        precio: 25000,
        color: 'blue',
        destacado: false
      },
      {
        codigo: '0003',
        nombre: 'Gears of War 4',
        stock: 100,
        precio: 15000,
        color: 'green',
        destacado: true
      },
      {
        codigo: '0004',
        nombre: 'Mario Tennis Aces',
        stock: 100,
        precio: 35000,
        color: 'yellow',
        destacado: false
      },
      {
        codigo: '0005',
        nombre: 'Bloodborne',
        stock: 100,
        precio: 10000,
        color: 'blue',
        destacado: false
      },
      {
        codigo: '0006',
        nombre: 'Forza Horizon 4',
        stock: 100,
        precio: 20000,
        color: 'red',
        destacado: true
      }
    ]
  },// fin de state
  getters: {
    productosConStock: state => {
      return state.productos.filter((producto) => {
        return producto.stock > 0;
      })
    },
    totalStock: state => {
      return state.productos.reduce((sumaTotal, producto) => {
        sumaTotal = sumaTotal + producto.stock;
        return sumaTotal
      }, 0)
    },
    productosPorBusqueda: state => {
      //state.busqueda
      if(state.busqueda === "") {
        return [];
      } else {
        return state.productos.filter((producto) => {
          return producto.nombre.includes(state.busqueda)
        })
      }
    }
  },// fin de getters
  mutations: {
    SET_BUSQUEDA(state, nuevaBusqueda) {
      state.busqueda = nuevaBusqueda;
    },
    vender: (state, producto) => {
      state.productos.map((p) => {
        if(p.codigo == producto.codigo)
          p.stock--
      })
      return state.productos.filter()
    }
  },// fin de mutations
  actions: {
    setBusqueda(context, nuevaBusqueda) {
      if (typeof nuevaBusqueda === "string") {
        context.commit("SET_BUSQUEDA", nuevaBusqueda)
      } else {
        console.warn(`nuevaBusqueda no es alfabética ${typeof nuevaBusqueda}`)
      }
    },
  }//fin de actions
});// fin de Store

export default store;
