<template>
    <div>
        <h3>Página de búsquedas</h3>
        <input
        type="text"
        placeholder="ingrese el producto a buscar"
        :value="$store.state.busqueda"
        @input="$store.dispatch('setBusqueda', Number.parseInt($event.target.value))"
        >

        <div>
            <ul
            v-if="$store.getters.productosPorBusqueda">
                <li></li>
            </ul>
        </div>


        
        <div>
            <ul>
                <li>Total de productos: {{ $store.state.productos.length }}</li>
                <li>Total en stock: {{ $store.getters.totalStock }} </li>
            </ul>
        </div>
        <ul>
            <li
            v-for="producto in productosConStock"
            :key="producto.codigo"
            :style="{'background-color': producto.color}"
            >
                <label> {{producto.codigo}} | {{producto.nombre}} | {{producto.stock}} | {{producto.precio}} | </label>
            </li>
        </ul>
    </div>
</template>


<script>
import {mapState} from 'vuex'
export default {
    computed: {
        productosConStock() {
            return this.$store.getters.productosConStock
        },
        totalStock() {
            return this.$store.getters.totalStock
        }
    },
    ...mapState({
        totalVentas: (state) => {
            return `Total : ${state.totalVentas}`
        },
        destacado: () => {}
    })
}
</script>