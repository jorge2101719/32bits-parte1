<template>
    <div>
        <h3>
            Ventas
        </h3>

        <ul v-for="producto in productosConStock" :key="producto.codigo">
            <li> {{producto.nombre}} | {{producto.stock}} | {{producto.precio}} </li>
        </ul>
    </div>
</template>

<script>
export default {
    computed: {
        productosConStock() {
            return this.$store.getters.productosConStock
        }
    }
}
</script>