<template>
  <div id="app">
    <!--<img alt="Vue logo" src="./assets/logo.png">-->
    <nav class="navbar bg-dark navbar-expand-lg">
    <ul class="nav nav-pills nav-fill nav-justified">
      <li class="nav-item">
        <router-link :to="{name: 'inicio'}" class="aspecto">Inicio</router-link>
      </li>
      <li class="nav-item">
        <router-link :to="{name: 'busquedas'}" class="aspecto">Búsquedas</router-link>
      </li>
      <li class="nav-item">
        <router-link :to="{name: 'ventas'}" class="aspecto">Ventas</router-link>
      </li>
      <li class="nav-item">
        <router-link :to="{name: 'total'}" class="aspecto">Total</router-link>
      </li>
    </ul>
    </nav>

    <transition name="vista">
      <router-view></router-view>
    </transition>
  </div>
</template>

<script>

export default {
}
</script>

<style scoped>

.vista-enter-active, .vista-leave-active {
    transition: opacity .1s;
}
.vista-enter, .vista-leave-to{
    opacity: 0;
}
.aspecto {
  color: white;
}
li {
  padding: 20px;
}
</style>
